
package com.example.wikirandom.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {

    @Query("SELECT * FROM favorite_articles ORDER BY savedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteArticleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(article: FavoriteArticleEntity)

    @Delete
    suspend fun deleteFavorite(article: FavoriteArticleEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_articles WHERE pageId = :pageId)")
    suspend fun isFavorite(pageId: Int): Boolean
}
