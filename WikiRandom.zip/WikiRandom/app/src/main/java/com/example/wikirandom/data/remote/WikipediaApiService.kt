
package com.example.wikirandom.data.remote

import retrofit2.http.GET

interface WikipediaApiService {
    @GET("page/random/summary")
    suspend fun getRandomArticle(): RandomArticleResponse
}
