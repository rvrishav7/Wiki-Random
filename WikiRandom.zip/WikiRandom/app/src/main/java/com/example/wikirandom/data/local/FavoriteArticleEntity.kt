
package com.example.wikirandom.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_articles")
data class FavoriteArticleEntity(
    @PrimaryKey val pageId: Int,
    val title: String,
    val extract: String,
    val description: String?,
    val thumbnailUrl: String?,
    val pageUrl: String,
    val savedAt: Long = System.currentTimeMillis()
)
