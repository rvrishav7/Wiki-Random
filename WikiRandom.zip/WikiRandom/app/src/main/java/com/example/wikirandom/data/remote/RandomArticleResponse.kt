package com.example.wikirandom.data.remote

import com.google.gson.annotations.SerializedName

data class RandomArticleResponse(
    @SerializedName("pageid") val pageId: Int,
    @SerializedName("title") val title: String,
    @SerializedName("extract") val extract: String,
    @SerializedName("description") val description: String?,
    @SerializedName("thumbnail") val thumbnail: Thumbnail?,
    @SerializedName("content_urls") val contentUrls: ContentUrls
)

data class Thumbnail(
    @SerializedName("source") val source: String,
    @SerializedName("width") val width: Int,
    @SerializedName("height") val height: Int
)

data class ContentUrls(
    @SerializedName("desktop") val desktop: PageUrl
)

data class PageUrl(
    @SerializedName("page") val page: String
)