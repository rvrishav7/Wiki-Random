package com.example.wikirandom.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.wikirandom.data.repository.WikiRepository
import com.example.wikirandom.ui.screens.article.ArticleDetailScreen
import com.example.wikirandom.ui.screens.favorites.FavoritesScreen
import com.example.wikirandom.ui.screens.favorites.FavoritesViewModel
import com.example.wikirandom.ui.screens.home.HomeScreen
import com.example.wikirandom.ui.screens.home.HomeViewModel
import java.net.URLDecoder
import java.net.URLEncoder

private object Destination {
    const val HOME = "home"
    const val FAVORITES = "favorites"
    const val ARTICLE = "article/{url}"

    fun articleRoute(url: String): String {
        val encoded = URLEncoder.encode(url, "UTF-8")
        return "article/$encoded"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(repository: WikiRepository) {
    val navController = rememberNavController()

    val homeViewModel: HomeViewModel = viewModel(
        factory = GenericViewModelFactory { HomeViewModel(repository) }
    )
    val favoritesViewModel: FavoritesViewModel = viewModel(
        factory = GenericViewModelFactory { FavoritesViewModel(repository) }
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val isArticleScreen = currentRoute == Destination.ARTICLE

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when {
                            isArticleScreen -> "Article"
                            currentRoute == Destination.FAVORITES -> "Favorites"
                            else -> "Discover"
                        }
                    )
                },
                navigationIcon = {
                    if (isArticleScreen) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (currentRoute == Destination.HOME) {
                        IconButton(onClick = { homeViewModel.loadInitialFeed() }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "New random articles")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!isArticleScreen) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute != Destination.FAVORITES,
                        onClick = { navController.navigate(Destination.HOME) },
                        icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        label = { Text("Discover") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Destination.FAVORITES,
                        onClick = { navController.navigate(Destination.FAVORITES) },
                        icon = { Icon(Icons.Filled.Favorite, contentDescription = null) },
                        label = { Text("Favorites") }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Destination.HOME) {
                HomeScreen(
                    viewModel = homeViewModel,
                    onArticleClick = { url -> navController.navigate(Destination.articleRoute(url)) }
                )
            }
            composable(Destination.FAVORITES) {
                FavoritesScreen(
                    viewModel = favoritesViewModel,
                    onArticleClick = { url -> navController.navigate(Destination.articleRoute(url)) }
                )
            }
            composable(route = Destination.ARTICLE) { backStackEntry: androidx.navigation.NavBackStackEntry ->
                val encodedUrl = backStackEntry.arguments?.getString("url") ?: ""
                val url = URLDecoder.decode(encodedUrl, "UTF-8")
                ArticleDetailScreen(url = url)
            }
        }
    }
}