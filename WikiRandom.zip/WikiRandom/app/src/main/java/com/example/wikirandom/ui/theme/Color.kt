
package com.example.wikirandom.ui.theme

import androidx.compose.ui.graphics.Color

val WikiBlue = Color(0xFF2A5DB0)
val WikiBlueDark = Color(0xFF143A75)
val WikiAccent = Color(0xFFF2A93B)
val SurfaceLight = Color(0xFFF8F9FB)
val SurfaceDark = Color(0xFF121417)
