
package com.example.wikirandom.ui.screens.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wikirandom.data.local.FavoriteArticleEntity
import com.example.wikirandom.data.repository.WikiRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FavoritesViewModel(private val repository: WikiRepository) : ViewModel() {

    val favorites: StateFlow<List<FavoriteArticleEntity>> = repository.getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun removeFavorite(article: FavoriteArticleEntity) {
        viewModelScope.launch {
            repository.removeFavorite(article)
        }
    }
}
