package com.example.wikirandom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.wikirandom.ui.AppRoot
import com.example.wikirandom.ui.theme.WikiRandomTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = application as WikiApp
            WikiRandomTheme {
                AppRoot(repository = app.repository)
            }
        }
    }
}