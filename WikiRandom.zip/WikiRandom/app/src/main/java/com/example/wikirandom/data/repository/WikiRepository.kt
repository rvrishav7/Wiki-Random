package com.example.wikirandom.data.repository

import com.example.wikirandom.data.local.FavoriteArticleEntity
import com.example.wikirandom.data.local.FavoriteDao
import com.example.wikirandom.data.remote.RandomArticleResponse
import com.example.wikirandom.data.remote.WikipediaApiService
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow

class WikiRepository(
    private val api: WikipediaApiService,
    private val favoriteDao: FavoriteDao
) {
    suspend fun fetchRandomArticle(): RandomArticleResponse = api.getRandomArticle()

    /**
     * Fetches [count] random articles, preferring ones that have a thumbnail image.
     * Over-fetches in parallel batches since many random Wikipedia pages have no image,
     * then fills any remaining slots with non-thumbnail articles rather than waiting forever.
     */
    suspend fun fetchRandomArticles(count: Int): List<RandomArticleResponse> = coroutineScope {
        val withImages = mutableListOf<RandomArticleResponse>()
        val withoutImages = mutableListOf<RandomArticleResponse>()
        var attempts = 0
        val maxAttempts = 4

        while (withImages.size < count && attempts < maxAttempts) {
            val needed = (count - withImages.size) * 2
            val batch = (1..needed)
                .map { async { runCatching { api.getRandomArticle() }.getOrNull() } }
                .mapNotNull { it.await() }

            batch.forEach { article ->
                if (article.thumbnail != null) withImages.add(article) else withoutImages.add(article)
            }
            attempts++
        }

        val result = (withImages + withoutImages).distinctBy { it.pageId }
        result.take(count)
    }

    fun getAllFavorites(): Flow<List<FavoriteArticleEntity>> = favoriteDao.getAllFavorites()

    suspend fun addFavorite(article: FavoriteArticleEntity) = favoriteDao.insertFavorite(article)

    suspend fun removeFavorite(article: FavoriteArticleEntity) = favoriteDao.deleteFavorite(article)

    suspend fun isFavorite(pageId: Int): Boolean = favoriteDao.isFavorite(pageId)
}