package com.example.wikirandom.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wikirandom.data.local.FavoriteArticleEntity
import com.example.wikirandom.data.remote.RandomArticleResponse
import com.example.wikirandom.data.repository.WikiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FeedItem(
    val article: RandomArticleResponse,
    val isFavorite: Boolean
)

data class HomeUiState(
    val items: List<FeedItem> = emptyList(),
    val isInitialLoading: Boolean = true,
    val isPrefetching: Boolean = false,
    val error: String? = null
)

class HomeViewModel(private val repository: WikiRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    // Larger pages so there's always a deep buffer ahead of the user
    private val INITIAL_PAGE_SIZE = 15
    private val PREFETCH_PAGE_SIZE = 15
    // Start prefetching once the user is within this many cards of the end
    private val PREFETCH_THRESHOLD = 6

    private var isFetchingMore = false

    init {
        loadInitialFeed()
    }

    fun loadInitialFeed() {
        viewModelScope.launch {
            _uiState.value = HomeUiState(isInitialLoading = true)
            try {
                val articles = repository.fetchRandomArticles(INITIAL_PAGE_SIZE)
                val items = articles.map { article ->
                    FeedItem(article, repository.isFavorite(article.pageId))
                }
                _uiState.value = HomeUiState(items = items, isInitialLoading = false)
            } catch (e: Exception) {
                _uiState.value = HomeUiState(
                    isInitialLoading = false,
                    error = e.localizedMessage ?: "Something went wrong"
                )
            }
        }
    }

    /** Call this with the current page index the user is viewing; silently tops up the buffer. */
    fun onPageViewed(currentPage: Int) {
        val current = _uiState.value
        val remaining = current.items.size - 1 - currentPage
        if (remaining <= PREFETCH_THRESHOLD && !isFetchingMore) {
            prefetchMore()
        }
    }

    private fun prefetchMore() {
        isFetchingMore = true
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isPrefetching = true)
            try {
                val articles = repository.fetchRandomArticles(PREFETCH_PAGE_SIZE)
                val existingIds = _uiState.value.items.map { it.article.pageId }.toSet()
                val newItems = articles
                    .filter { it.pageId !in existingIds }
                    .map { article -> FeedItem(article, repository.isFavorite(article.pageId)) }

                _uiState.value = _uiState.value.copy(
                    items = _uiState.value.items + newItems,
                    isPrefetching = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isPrefetching = false)
            } finally {
                isFetchingMore = false
            }
        }
    }

    fun toggleFavorite(pageId: Int) {
        val current = _uiState.value
        val index = current.items.indexOfFirst { it.article.pageId == pageId }
        if (index == -1) return

        viewModelScope.launch {
            val item = current.items[index]
            val article = item.article
            val entity = FavoriteArticleEntity(
                pageId = article.pageId,
                title = article.title,
                extract = article.extract,
                description = article.description,
                thumbnailUrl = article.thumbnail?.source,
                pageUrl = article.contentUrls.desktop.page
            )
            if (item.isFavorite) {
                repository.removeFavorite(entity)
            } else {
                repository.addFavorite(entity)
            }

            val updatedItems = _uiState.value.items.toMutableList()
            val updatedIndex = updatedItems.indexOfFirst { it.article.pageId == pageId }
            if (updatedIndex != -1) {
                updatedItems[updatedIndex] = updatedItems[updatedIndex].copy(isFavorite = !item.isFavorite)
                _uiState.value = _uiState.value.copy(items = updatedItems)
            }
        }
    }
}