package com.example.wikirandom.ui.screens.home

import android.content.Intent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.wikirandom.ui.components.ArticleCard

@Composable
fun HomeScreen(viewModel: HomeViewModel, onArticleClick: (String) -> Unit) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            uiState.isInitialLoading -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }

            uiState.error != null && uiState.items.isEmpty() -> {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Couldn't load articles")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(uiState.error ?: "", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.loadInitialFeed() }) { Text("Try again") }
                }
            }

            else -> {
                val pagerState = rememberPagerState(pageCount = { uiState.items.size })

                VerticalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val item = uiState.items[page]
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ArticleCard(
                            article = item.article,
                            isFavorite = item.isFavorite,
                            onToggleFavorite = { viewModel.toggleFavorite(item.article.pageId) },
                            onShare = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "${item.article.title}\n${item.article.contentUrls.desktop.page}"
                                    )
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share article"))
                            },
                            onReadFull = { onArticleClick(item.article.contentUrls.desktop.page) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Silently prefetch the next 15 articles in the background as the user nears the end
                LaunchedEffect(pagerState) {
                    snapshotFlow { pagerState.currentPage }
                        .collect { page -> viewModel.onPageViewed(page) }
                }
            }
        }
    }
}