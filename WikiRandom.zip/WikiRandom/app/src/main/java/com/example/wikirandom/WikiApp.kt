
package com.example.wikirandom

import android.app.Application
import com.example.wikirandom.data.local.AppDatabase
import com.example.wikirandom.data.remote.RetrofitInstance
import com.example.wikirandom.data.repository.WikiRepository

class WikiApp : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { WikiRepository(RetrofitInstance.api, database.favoriteDao()) }
}
